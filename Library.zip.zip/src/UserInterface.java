
public interface UserInterface {
	public void signUp();
	public void signIn();
	public void signOut();
	}
