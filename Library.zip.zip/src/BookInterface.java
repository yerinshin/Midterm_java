
public interface BookInterface {
	public void addBook();
	public void deleteBook();
	public void rentBook();
	public void returnBook();
}
