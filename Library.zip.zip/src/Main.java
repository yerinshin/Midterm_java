public class Main {
	public static void main(String[] args) {
		LibraryView menu = new LibraryView();
		menu.process();


	}
}
